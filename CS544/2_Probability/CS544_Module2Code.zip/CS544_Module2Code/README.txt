Additional Installation for Module2

 - R package 'prob'

From RStudio, Tools->Install Packages (start typing prob and select prob from the list shown).

If in the console, you see a message like compile from sources, make sure to type No option.

After successful installation, you can load the library as shown in the Module.

library(prob)
