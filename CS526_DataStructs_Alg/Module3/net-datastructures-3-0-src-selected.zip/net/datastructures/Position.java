package net.datastructures;
/**
 * An interface for a position, which is a holder object storing a
 * single element.
 * @author Roberto Tamassia
 */
public interface Position {
  /** Returns the element stored at this position. */
  Object element();
}
