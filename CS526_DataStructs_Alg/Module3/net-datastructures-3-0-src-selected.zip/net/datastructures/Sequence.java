package net.datastructures;
/**
 * An interface for a sequence, a data structure supporting all
 * operations of a vector and a list.
 * @author Roberto Tamassia, Michael Goodrich
 */
public interface Sequence extends List, Vector {
  /** Returns the position containing the element at the given rank. */
  public Position atRank(int r) throws BoundaryViolationException;
  /** Returns the rank of the element stored at the given position. */
  public int rankOf(Position p) throws InvalidPositionException;
}
