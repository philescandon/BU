package net.datastructures;
/**
 * Interface for a vector.
 * @author Michael Goodrich, Roberto Tamassia
 */
public interface Vector {
  /** Returns the number of elements in the vector. */
  public int size();
  /** Returns whether the vector is empty. */
  public boolean isEmpty();
  /** Returns the element stored at the given rank. */
  /** Returns the element stored at the given rank. 
   * @param r Rank to query
   * @throws BoundaryViolationException if <tt>r</tt> < 0 or
   * <tt>r</tt> > {@link #size()} - 1
   */
  public Object elemAtRank(int r) throws BoundaryViolationException;
  /** Replaces the element stored at the given rank. */
  /** Replaces the element stored at the given rank.
   * @param r Rank at which to replace
   * @throws BoundaryViolationException if <tt>r</tt> < 0 or
   * <tt>r</tt> > {@link #size()} - 1
   */
  public Object replaceAtRank(int r, Object e) throws BoundaryViolationException;
  /** Inserts an element at the given rank. */
  /** Inserts an element at the given rank.
   * @param r Rank at which to replace
   * @throws BoundaryViolationException if <tt>r</tt> < 0 or
   * <tt>r</tt> > {@link #size()}
   */
  public void insertAtRank(int r, Object e) throws BoundaryViolationException;
  /** Removes the element stored at the given rank. */
  /** Removes the element stored at the given rank.
   * @param r Rank at which to replace
   * @throws BoundaryViolationException if <tt>r</tt> < 0 or
   * <tt>r</tt> > {@link #size()} - 1
   */
  public Object removeAtRank(int r) throws BoundaryViolationException;
}
