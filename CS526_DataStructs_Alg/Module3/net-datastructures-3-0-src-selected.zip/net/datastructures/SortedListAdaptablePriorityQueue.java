package net.datastructures;
import java.util.Comparator;
/**
 * Realization of an adaptable priority queue by means of a sorted
 * linked-list in nondecreasing order. Much functionality is
 * inherited.
 * @see SortedListPriorityQueue
 * @author Roberto Tamassia, Eric Zamore
 */
/** Implementation of a priority queue by means of a sorted list */
public class SortedListAdaptablePriorityQueue
  extends SortedListPriorityQueue implements AdaptablePriorityQueue {
  /** Creates the priority queue with the default comparator. */
  public SortedListAdaptablePriorityQueue() { 
    super();
  }
  /** Creates the priority queue with the given comparator. */
  public SortedListAdaptablePriorityQueue(Comparator comp) { 
    super(comp);
  }
  /** Creates the priority queue with the given comparator and list.
   * The list is assumed to be sorted in nondecreasing order.*/
  public SortedListAdaptablePriorityQueue(List list, Comparator comp) { 
    super(list, comp);
  }
  /** Inserts a key-value pair and returns the entry created. */
  public Entry insert (Object k, Object v) throws InvalidKeyException {
    checkKey(k);
    LocationAwareEntry entry = new LocationAwareEntry(k,v);
    insertEntry(entry);
    entry.setLocation(actionPos);
    return entry;
  }
  /** Removes and returns the given entry. */
  public Entry remove(Entry entry) {
    checkEntry(entry);
    LocationAwareEntry e = (LocationAwareEntry) entry;
    Position p = e.location();
    L.remove(p);
    e.setLocation(null);
    return e;
  }
  /** Replaces the key of the given entry. */
  public Object replaceKey(Entry entry, Object k) {
    checkKey(k);
    checkEntry(entry);
    LocationAwareEntry e = (LocationAwareEntry) remove(entry);
    Object oldKey = e.setKey(k);
    insertEntry(e);
    e.setLocation(actionPos);
    return oldKey;
  }
  /** Replaces the value of the given entry. */
  public Object replaceValue(Entry e, Object value) {
    checkEntry(e);
    Object oldValue = ((LocationAwareEntry) e).setValue(value);
    return oldValue;
  }
  /** Determines whether a given entry is valid. */
  protected void checkEntry(Entry ent) throws InvalidEntryException {
    if(ent == null || !(ent instanceof LocationAwareEntry))
      throw new InvalidEntryException("invalid entry");
  }
  /** Inner class for a location-aware entry. */
  protected static class LocationAwareEntry 
    extends MyEntry implements Entry {
    /** Position where the entry is stored. */
    private Position loc;
    public LocationAwareEntry(Object key, Object value) {
      super(key, value);
    }
    public LocationAwareEntry(Object key, Object value, Position pos) {
      super(key, value);
      loc = pos;
    }
    protected Position location() {
      return loc;
    }
    protected Position setLocation(Position pos) {
      Position oldPosition = location();
      loc = pos;
      return oldPosition;
    }
    protected Object setKey(Object key) {
      Object oldKey = key();
      k = key;
      return oldKey;
    }
    protected Object setValue(Object value) {
      Object oldValue = value();
      v = value;
      return oldValue;
    }
  }
}





