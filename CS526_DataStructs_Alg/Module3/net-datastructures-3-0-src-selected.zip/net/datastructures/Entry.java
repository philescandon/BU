package net.datastructures;

/** Interface for a key-value pair entry **/
public interface Entry {
  /** Returns the key stored in this entry. */
  public Object key();
  /** Returns the value stored in this entry. */
  public Object value();
}
