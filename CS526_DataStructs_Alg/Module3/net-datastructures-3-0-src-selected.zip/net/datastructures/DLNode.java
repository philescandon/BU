package net.datastructures;

/**
 * A simple node class for a doubly-linked list.  Each node has a
 * reference to a stored element, a previous node, and a next node.
 * This class differs from the <code>DNode</code> class in that it
 * does not implement the <code>Position</code> interface, for
 * simplification purposes.
 *
 * @author Roberto Tamassia
 * @see DNode
 * @see Position
 */

public class DLNode {
  private Object element;
  private DLNode next, prev;
  DLNode() { this(null, null, null); }
  DLNode(Object e, DLNode p, DLNode n) {
    element = e;
    next = n;
    prev = p;
  }
  public void setElement(Object newElem) { element = newElem; }
  public void setNext(DLNode newNext) { next = newNext; }
  public void setPrev(DLNode newPrev) { prev = newPrev; }
  public Object getElement() { return element; }
  public DLNode getNext() { return next; }
  public DLNode getPrev() { return prev; }
}
