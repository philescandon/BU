package net.datastructures;
import java.util.Iterator;
import java.lang.Boolean;

/** This class specializes DFS to determine whether the graph is connected. */
public class ConnectivityDFS extends DFS {
  protected int reached;
  /** Executes the DFS algorithm. 
   * @param g Input graph
   * @param start Start vertex
   * @param info unused variable (can be anything)
   * @return {@link Boolean Boolean} with value <tt>true</tt> if the graph is
   * connected, <tt>false</tt> otherwise
   */
  public Object execute(Graph g, Vertex start, Object info) {
    init(g);
    int n = 0;
    Iterator V = G.vertices();
    while (V.hasNext()) {
      V.next();
      n++;
    }
    reached = 0;
    dfsTraversal(start);
    return new Boolean(reached == n);
  }
  protected void startVisit(Vertex v) { reached++; }

}
