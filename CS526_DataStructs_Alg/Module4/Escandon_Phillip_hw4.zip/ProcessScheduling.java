
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import net.datastructures.Entry;
import net.datastructures.HeapPriorityQueue;

/**
 * @author phill
 *
 */
public class ProcessScheduling {

	/**
	 * 
	 */
	public ProcessScheduling(){ }
	
	// nested class Process
	/**
	 * @author phill
	 *
	 */
	protected static class Process {
		private int priority;
		private int id;
		private int arrivalTime;
		private int duration;
		  
		/**
		 * Default Constructor
		 */
		public Process(){
		  priority = 0;
		  id = 0;
		  arrivalTime = 0;
		  duration = 0;
		}
		
		/**
		 * Constructor
		 * @author phill
		 * @param pr = priority
		 * @param id = Id
		 * @param at = arrivalTime
		 * @param dr = duration
		 */
		public Process(int pr, int id, int at, int dr) {
			this.priority = pr;
			this.id = id;
			this.arrivalTime = at;
			this.duration = dr;
		};
		
		  
		public int getPriority() {return priority;}
		public int getId() {return id;}
		public int getArrivalTime() {return arrivalTime;}
		public int getDuration() {return duration;}
		
		public void setPriority(int pr) {priority = pr;}
		public void setId(int id) {this.id = id;}
		public void setArrivalTime(int at) {arrivalTime = at;}
		public void setDuration(int dr) {duration = dr;}	  
	}
	
	// print an entry in priority queue
	// in parameter e, an entry of priority queue
	/**
	 * @param e
	 */
	public static void printEntry(Entry<Integer, Process> e){
		System.out.println("Process id = " + e.getValue().getId());
		System.out.println("\tPriority = " + e.getKey());
		System.out.println("\tArrival = " + e.getValue().getArrivalTime());
		System.out.println("\tDuration  = " + e.getValue().getDuration());
	}
		
	// read processes from input file and add them to ArrayList
	// receive empty ArrayList, list
	// return number of processes, numProcesses
	/**
	 * @param list
	 * @return
	 * @throws IOException
	 */
	public static int readProcesses(ArrayList<Process> list) throws IOException{

		String[] tokens;
		// used a debug file for quicker debugging steps
		Scanner inputFile = new Scanner (new File("process_scheduling_in.txt"));
		int numProcesses = 0;
		while (inputFile.hasNext()){
			tokens = inputFile.nextLine().trim().split("\\s+");
//			Process p = new Process();
			int id = Integer.parseInt(tokens[0]);
			int pr = Integer.parseInt(tokens[1]);
			int dr = Integer.parseInt(tokens[2]);
			int at = Integer.parseInt(tokens[3]);
			Process p = new Process(pr,id,at,dr);
			list.add(p);
			numProcesses++;
			// for debugging
			System.out.println("Id = " + id + ", priority = " + pr + ", duration = " + dr + ", arrival time = " + at);
		}
		System.out.println();
		inputFile.close();
		return numProcesses;
	}
	
	

	
	/**
	 * @param args
	 * @throws IOException
	 */
	/**
	 * @param args
	 * @throws IOException
	 */
	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		
		  // create empty priority queue
		  HeapPriorityQueue<Integer, Process> q = new HeapPriorityQueue<>();
		  // create empty ArrayList for the Processes
		  ArrayList<Process> processList = new ArrayList<Process>();  	  
		  
		  
		  // read processes from input file
		  int numProcesses = readProcesses(processList);

//		Set up the timing and a two new process objs
		  int currentTime = 0;
		  int removedTime = 0;
		  double totalWaitTime = 0;
		  boolean running = false;
		  
		  // This p is for the process from the processList
		  Process p = new Process();
		  // This qp is for the process from the queue
		  Process qp = new Process();
		  
	/*
	 * Ideas:  We have 
	 * 	1. ArrayList with the Processes
	 *  2. Priority Queue
	 *  3. Timer (currentTime, removedTime, totalWaitTime)
	 *  4. Output file
	 *  5. Used a debug file with shorter insertion and duration times so I could see
	 *     the process in the debugger.
	 * 	
	 *   At the appropriate arrival time - remove the process and place in the Priority Queue
	 *   If no processes are running, remove process from queue and track time.
	 *   Track the running process while filling the Priority Queue
	 *   At some point the processArray should be empty and we are left with the priorityQueue with 
	 *   processes that still need to be 'executed'
	 * 
	 * 
	 */
		  
//		  FileWriter writer = new FileWriter("./process_scheduling_out_Phil.txt");
		  FileWriter writer = new FileWriter("./process_scheduling_out.txt");
		  
	  
//	Insert process list into queue  
		  
		  // Get a process from the processList
		  for(int i = 0; i< processList.size();i++) {
			  p = processList.get(i);
			  // At the appropriate time insert into queue
			  // after checking the running state and queue state
			  while(currentTime<p.getArrivalTime()) {
				  currentTime++;
				  if(running) {
					  
					  if ((currentTime - removedTime) >= qp.getDuration()){
						  writer.write("Process " + qp.getId() + " finished processing at time " + currentTime + "\n ");
						  running = false;
					  }
					  // if the p WAS running to get into this loop, but jumped into the first
					  // if and finished... begin another process.
					  if(!running && !q.isEmpty() ) {
					  qp = q.removeMin().getValue();
					  totalWaitTime += currentTime - qp.getArrivalTime();
					  writer.write("Process removed from queue is: id = " + qp.getId() 
					  + " at time: " + currentTime 
					  + ", wait time : " + ( currentTime - qp.getArrivalTime() ) 
					  + " Total wait time :"+ totalWaitTime + "\n");
					  writer.write("Process id: " + qp.getId() + "\n");
					  writer.write("\tPriority: "+ qp.getPriority() + "\n");
					  writer.write("\tArrival: " + qp.getArrivalTime() + "\n");
					  writer.write("\tDuration: " + qp.getDuration() + "\n");
					  running = true;
					  removedTime = currentTime;
					  currentTime++;
					  }
					 
				  }//if 
			  	} // while
			  	// Insert the process into the priorityQueue
			  	q.insert(processList.get(i).getPriority(), processList.get(i));
			  	// after insertion check to see if you need to start
			  	// the initial process 
			  	
				if(!running && !q.isEmpty() ) {			  	
					  qp = q.removeMin().getValue();
					  totalWaitTime += currentTime - qp.getArrivalTime();
					  writer.write("Process removed from queue is: id = " + qp.getId() 
					  + " at time: " + currentTime 
					  + ", wait time : " + ( currentTime - qp.getArrivalTime() ) 
					  + " Total wait time :"+ totalWaitTime + "\n");
					  writer.write("Process id: " + qp.getId() + "\n");
					  writer.write("\tPriority: "+ qp.getPriority() + "\n");
					  writer.write("\tArrival: " + qp.getArrivalTime() + "\n");
					  writer.write("\tDuration: " + qp.getDuration() + "\n");
					  running = true;
					  removedTime = currentTime;
				  }

				  if(running) {
					  if ((currentTime - removedTime) >= qp.getDuration()){
						  writer.write("Process " + qp.getId() + " finished processing at time " + currentTime + "\n ");
						  running = false;
					  }
				  }	// if
		  } 
		  // for loop finished - all process are in the  Queue - 
		  // now finish anything left in the PriorityQueue
		  // should only keep track of 
		  // q - the priority queue and 
		  // qp - the process from the queue. 
		  
		writer.write("Process Array is now empty at time: " + currentTime+ "\n"); 
		
		
		while (running) {	
			  currentTime++;
			  if(running) {
				  if ((currentTime - removedTime) >= qp.getDuration()){
					  writer.write("Process " + qp.getId() + " finished processing at time " + currentTime + "\n ");
					  running = false;
				  }
				  //TODO : create a f(x) from the section below
				  if(!running && !q.isEmpty() ) {
				  qp = q.removeMin().getValue();
				  totalWaitTime += currentTime - qp.getArrivalTime();
				  writer.write("Process removed from queue is: id = " + qp.getId() 
				  + " at time: " + currentTime 
				  + ", wait time : " + ( currentTime - qp.getArrivalTime() ) 
				  + " Total wait time :"+ totalWaitTime + "\n");
				  writer.write("Process id: " + qp.getId() + "\n");
				  writer.write("\tPriority: "+ qp.getPriority() + "\n");
				  writer.write("\tArrival: " + qp.getArrivalTime() + "\n");
				  writer.write("\tDuration: " + qp.getDuration() + "\n");
				  running = true;
				  removedTime = currentTime;
				  currentTime++;
				  }
				  
			  }//if 
		}
		
		writer.write("\nSize of Queue : " + q.size() + "\n");
		writer.write("Total Wait time :"+ totalWaitTime + "\n");
		writer.write("Average Wait time:" + totalWaitTime/numProcesses + "\n");
		writer.close();
	}
	



}