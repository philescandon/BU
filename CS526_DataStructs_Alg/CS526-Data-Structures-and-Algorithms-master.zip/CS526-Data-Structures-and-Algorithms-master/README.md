# CS526 Data Structures and Algorithms 
<pre>
hw1   Basic Java  
hw2   Array List  
hw3   Linked List  
hw4   Algorithim Analysis  
hw5   Recursive Methods &amp; Stacks  
hw6   Binary Search  
hw7   Priority Queue  
hw8   Hash Map  
hw9   Sortings  
hw10   Dynamic Programming  
project   Shortest Path  
</pre>
