
public class Hw1_part1 {

	public static void determineGrade(int homework, int project, int midterm, int finalExam) {
		
		// implement this method
	}
	
	public static void main(String[] args) {
		
		// test the determineGrade method
		determineGrade(100, 90, 85, 95);
		determineGrade(100, 100, 90, 75);
	}

}
