
public class Hw1_part2 {

	public static void stats(int[] a) {
		
		// implement this method
		
	}
	
	public static void main(String[] args) {
		
		// test the stats method
		int[] a = {10, 20, 30, 40, 50};
		int[] b = {5, 15, 25, 10, 65, 30, 55};
		stats(a);
		stats(b);
	}

}
