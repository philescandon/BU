

public class SampleProgram1 {

	public static void main(String[] args) {

		System.out.println("Has only main method");

	}

}
